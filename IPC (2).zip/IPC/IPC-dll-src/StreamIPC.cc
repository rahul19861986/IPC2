#include "StreamIPC.h"

#include <cereal/archives/json.hpp>
#include <cereal/types/string.hpp>
#include <cereal/types/vector.hpp>

#include <libipc/ipc.h>

#define MESSAGES_IPC_NAME "messages-ipc"
#define STREAMS_IPC_NAME "streams-ipc"

template <class Archive> void serialize(Archive &ar, Stream &s) {
  ar(cereal::make_nvp("data", s.data),
     cereal::make_nvp("time-stamp", s.timestamp), cereal::make_nvp("dt", s.dt),
     cereal::make_nvp("stream-id", s.stream_id));
}

thread_local ipc::channel cpp_ipc_messages;
thread_local ipc::channel cpp_ipc_streams;
thread_local ipc::channel labview_ipc_messages;
thread_local ipc::channel labview_ipc_streams;

void cppInit() {
  cpp_ipc_streams = ipc::channel(STREAMS_IPC_NAME, ipc::receiver);
  cpp_ipc_messages = ipc::channel(MESSAGES_IPC_NAME, ipc::sender);
}

void labviewInit() {
  labview_ipc_streams = ipc::channel(STREAMS_IPC_NAME, ipc::sender);
  labview_ipc_messages = ipc::channel(MESSAGES_IPC_NAME, ipc::receiver);
}

void cppDestroy() {
  cpp_ipc_streams.disconnect();
  cpp_ipc_messages.disconnect();
}

void labviewDestroy() {
  labview_ipc_streams.disconnect();
  labview_ipc_messages.disconnect();
}

void sendStream(int stream_id, char *timestamp, double dt, double *data,
                int length) {
  std::vector data_vec{data, data + length};
  Stream s{{data, data + length}, dt, stream_id, timestamp};
  std::stringstream ss;
  {
    cereal::JSONOutputArchive archive(ss);
    archive(s);
  }
  std::string msg = ss.str();
  labview_ipc_streams.send(msg);
}

Stream getStream() {
  auto buf = cpp_ipc_streams.recv();
  char *msg = static_cast<char *>(buf.data());
  std::stringstream ss{std::string(msg)};
  Stream s;
  {
    cereal::JSONInputArchive archive(ss);
    archive(s);
  }
  return s;
}

void sendMessage(const char *msg) {
  cpp_ipc_messages.wait_for_recv(1);
  cpp_ipc_messages.send(std::string(msg));
}

char *getMessage(void) {
  auto buf = labview_ipc_messages.recv();
  char *msg = (char *)malloc(buf.size());
  memcpy(msg, buf.data(), buf.size());
  return msg;
}
