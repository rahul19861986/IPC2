#pragma once

#if defined(__linux__)
#define __declspec(dllexport)
#endif

#ifdef __cplusplus
#include <string>
#include <vector>

struct Stream {
  inline Stream() = default;

  std::vector<double> data;
  double dt;
  int stream_id;
  std::string timestamp;
};
__declspec(dllexport) Stream getStream();
#endif

#ifdef __cplusplus
extern "C" {
#endif
__declspec(dllexport) void cppInit();
__declspec(dllexport) void labviewInit();
__declspec(dllexport) void cppDestroy();
__declspec(dllexport) void labviewDestroy();
__declspec(dllexport) void sendStream(int stream_id, char *timestamp, double dt,
                                      double *data, int length);
__declspec(dllexport) void sendMessage(const char *msg);
__declspec(dllexport) char *getMessage(void);
#ifdef __cplusplus
}
#endif
