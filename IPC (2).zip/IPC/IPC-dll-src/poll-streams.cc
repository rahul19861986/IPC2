#include "StreamIPC.h"
#include <cstddef>
#include <iostream>

int main() {
  cppInit();

  std::size_t stream_count = 0;
  while (1) {
    Stream s = getStream();
    std::cout << "read stream with id: " << s.stream_id << std::endl;
    std::cout << "number of read streams" << ++stream_count << std::endl;
    std::cout << "ARRAYSIZE" << s. << std::endl;
  }

  cppDestroy();
}
