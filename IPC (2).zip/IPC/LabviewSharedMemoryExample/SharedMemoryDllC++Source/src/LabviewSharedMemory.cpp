/* Call Library source file */
//Shared Memory for Matb//

#include "LabviewSharedMemory.h"

static HANDLE ghMapObject=NULL;

extern "C"{
_declspec(dllexport) DWORD SharedMemoryCreate(void);
_declspec(dllexport) DWORD SharedMemoryRead(float *x1[]);
_declspec(dllexport) DWORD SharedMemoryWrite(float *y1[]);
_declspec(dllexport) DWORD SharedMemoryClose(void);
}


_declspec(dllexport) DWORD SharedMemoryCreate(void)
{
	if (!ghMapObject){
		ghMapObject=CreateFileMapping((HANDLE) 0XFFFFFFFF,NULL,PAGE_READWRITE,0,100*sizeof (float),"vitpshared");}
	return(0);

}

_declspec(dllexport) DWORD SharedMemoryRead(float *x1[])
	{


float *MapView;

	
		//share memory Read init


		
		ghMapObject=OpenFileMapping(FILE_MAP_ALL_ACCESS,FALSE,"vitpshared");

		if (ghMapObject)
		{
			MapView=(float*)MapViewOfFile(ghMapObject,FILE_MAP_ALL_ACCESS,0,0,0);

			if (MapView)
			{
				CopyMemory(x1,MapView,100*sizeof(float));
	
		

				UnmapViewOfFile(MapView);
					return(0);
			}
			else
				return GetLastError();
		}
		else
			return GetLastError();
}
_declspec(dllexport) DWORD SharedMemoryWrite(float *y1[])
	{


float *MapView;

	
		//share memory write init


		if (!ghMapObject)
		ghMapObject=OpenFileMapping(FILE_MAP_ALL_ACCESS,FALSE,"vitpshared");

		if (ghMapObject)
		{
			MapView=(float*)MapViewOfFile(ghMapObject,FILE_MAP_ALL_ACCESS,0,0,0);

			if (MapView)
			{
				CopyMemory(MapView,y1,100*sizeof(float));


		

				UnmapViewOfFile(MapView);
					return(0);
			}
			else
				return GetLastError();
		}
		else
			return GetLastError();
}

_declspec(dllexport) DWORD SharedMemoryClose(void)
{
	if(ghMapObject)
	{
		CloseHandle(ghMapObject);
		ghMapObject = NULL;
	}
	return (0);
}



