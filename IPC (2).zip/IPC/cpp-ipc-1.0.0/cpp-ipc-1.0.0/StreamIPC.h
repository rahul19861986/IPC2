#pragma once

#if defined(__linux__)
#define __declspec(dllexport)
#endif

#ifdef __cplusplus
#include <string>
#include <vector>

struct Stream {
  inline Stream() = default;

  std::vector<double> data;
  double dt;
  int stream_id;
  std::string timestamp;
};
__declspec(dllexport) Stream getStream();
#endif

#ifdef __cplusplus
extern "C" {
#endif
__declspec(dllexport) void cppInit();
__declspec(dllexport) void labviewInit(); // this functions intializes the ipc for the labview side
__declspec(dllexport) void cppDestroy();
__declspec(dllexport) void labviewDestroy(); // when you are not going to send anymore streams call this function 
__declspec(dllexport) void sendStream(int stream_id, char *timestamp, double dt,
                                      double *data, int length); // this sends a stream from labview to cpp
__declspec(dllexport) void sendMessage(const char *msg);
__declspec(dllexport) char *getMessage(void); // this functions return a message sent from the cpp side
#ifdef __cplusplus
}
#endif
