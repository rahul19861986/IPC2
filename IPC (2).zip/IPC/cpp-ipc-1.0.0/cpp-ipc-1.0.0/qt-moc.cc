#include "StreamIPC.h"
#include <cereal/archives/json.hpp>
#include <cereal/types/string.hpp>
#include <cereal/types/vector.hpp>
#include <cstdio>
#include <iostream>

template <class Archive> void serialize(Archive &ar, Stream &s) {
  ar(cereal::make_nvp("data", s.data),
     cereal::make_nvp("time-stamp", s.timestamp), cereal::make_nvp("dt", s.dt),
     cereal::make_nvp("stream-id", s.stream_id));
}

int main() {
  cppInit();

  char msg[1024] = "";
  for (int i = 0; i < 300; i++) {
    std::sprintf(msg, "Send Stream %d", i);
    sendMessage(msg);
    Stream s = getStream();
    cereal::JSONOutputArchive output(std::cout);
    output(s);
  }

  sendMessage("Exit");

  cppDestroy();
}
